
export const CITY_CENTER: [number, number] = [-26.2041, 28.0473]; // Johannesburg, South Africa
